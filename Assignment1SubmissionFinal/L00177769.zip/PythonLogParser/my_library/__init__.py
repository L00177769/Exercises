from .get_manufacturer import get_manufacturer
from .remove_brackets import remove_brackets











copyright = "© MA 2022"
