"""
main.py
By: Martina Atkinson
Date: 20OCT22
"""
from Source.directory_utilities import detect_os, detect_working_directory
print(detect_os())
print(detect_working_directory())