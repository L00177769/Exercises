a = 1
b = 2
c = "JOR"
print(a+b)
print(a+B)
print(a+c)
   