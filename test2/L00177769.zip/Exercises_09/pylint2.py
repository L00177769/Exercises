"""
Script: pylint2.py
By: Martina Atkinson(L00177769)
Purpose : Demonstrates Pylint Static Code Analyser
Prerequisites:None
Tested: 15/10/2022
"""

A = 1
B = 2
C = "JOR"
print(A+B)
print(A+B)
print(A, C)
   