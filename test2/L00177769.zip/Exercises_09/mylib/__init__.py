"""
Script: _init_.py
By: Martina Atkinson
Purpose: Demonstrate the use of Packages - collection of modueles
Prerequisites: None
Tested: 1/10/2022
"""


# creates a gobal variable 
copyright = "© MARTINA 2022"