"""
Script: tcp.py
By: Martina Atkinson(L00177769)
Purpose : Settings for TCP Connection
Prerequisites:None
Tested: 15/10/2022
"""





TCP = {
 "SERVER_TCP_IPv4": '192.168.5.230',
 "SERVER_PORT": 23
}
