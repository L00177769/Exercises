"""
Script: udp.py
By: Martina Atkinson(L00177769)
Purpose : Settings for UDP Connection 
Prerequisites:None
Tested: 15/10/2022
"""



UDP = {
"SERVER_UDP_IPv4": '127.0.0.1',
"CLIENT_UDP_IPv4": '127.0.0.0',
"SERVER_PORT": 23
}
